package org.com.poojitha.interviewscreening;

import java.util.Scanner;

/*@author:Poojitha
 * Guessing Game -Pre Interview Screening
 * Written on 2/12/2015
 */
public class Guessing {
	static int myguess;
	static String guess;
	static int avg;
	static int low = 0;
	static int high = 100;

	// using average concept to reduce number of iterations
	public static void average() {
		avg = (low + high) / 2;
		myguess = avg;
	}

	public static void main(String args[]) {
		String process;
		myguess = high;
		Scanner sc1 = new Scanner(System.in);
		// This loop will be terminated when you enter "ready"
		do {
			System.out.println("Welcome to number guessing game.\n"
					+ "Please guess a number(between 1 and 100) in your mind\n"
					+ "When you are ready type:ready and press enter ");
			String guess1 = sc1.next();
			guess = guess1;

		} while (!guess.equalsIgnoreCase("ready"));// To force the user to enter
													// "ready"
		while (guess.equalsIgnoreCase("ready")) {
			average();
			System.out.println("My guess is " + myguess
					+ " If its correct enter yes\n"
					+ "else enter lower if your number is lower \n"
					+ "or higher if your number is higher \n");
			process = sc1.next();
			if (process.equalsIgnoreCase("lower")) {
				lower();
			}
			if (process.equalsIgnoreCase("higher")) {
				higher();
			}
			if (process.equalsIgnoreCase("yes")) {
				System.out.println("Ur guess is " + myguess);
				guess = "yes";
			}
			if (process.equalsIgnoreCase("end")) {
				System.out.println("Ur guess is " + myguess);
				guess = "end";
			}
		}

		sc1.close();
	}

	// To guess the lower number accordingly,If the user enter "lower"
	private static void lower() {

		high = avg;

		average();

	}

	// To guess the higher number accordingly,If the user enter "higher"
	private static void higher() {

		low = avg;

		average();

	}
}